a=float(input())
k=a*1000
print(k)